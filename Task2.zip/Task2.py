import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
df = pd.read_csv(r"C:\Users\vimal\Downloads\Dataset .csv")

# Drop unnecessary columns
df = df.drop(['Restaurant ID', 'Restaurant Name', 'Address', 'Locality Verbose',
              'Switch to order menu', 'Rating color', 'Rating text'], axis=1)

# Fill missing cuisines
df['Cuisines'] = df['Cuisines'].fillna('Unknown')

# Make matching easier
df['Cuisines'] = df['Cuisines'].str.lower()

# User preferences (edit these)
user_pref = {
    'cuisine': 'indian',
    'price_range': 2,
    'has_table_booking': 'Yes'
}

# Filter recommendations
recommendations = df[
    df['Cuisines'].str.contains(user_pref['cuisine'], case=False) &
    (df['Price range'] == user_pref['price_range']) &
    (df['Has Table booking'] == user_pref['has_table_booking'])
]

# Sort top 10
recommendations = recommendations.sort_values(by='Aggregate rating', ascending=False).head(10)

# Show basic info
print("Top 10 Restaurant Recommendations:\n")
print(recommendations[['City', 'Locality', 'Cuisines', 'Price range', 'Aggregate rating', 'Votes']])

# Reset index for plotting
recommendations = recommendations.reset_index(drop=True)

# Plot ratings
plt.figure(figsize=(10, 6))
sns.barplot(x='Aggregate rating', y=recommendations.index, data=recommendations, palette='viridis')
plt.title('Top Recommended Restaurants by Rating')
plt.xlabel('Aggregate Rating')
plt.ylabel('Restaurant Index')
plt.tight_layout()
plt.show()
