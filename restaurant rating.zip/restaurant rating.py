# Step 1: Import Libraries
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Step 2: Load the Dataset
df = pd.read_csv(r"C:\Users\vimal\Downloads\Dataset .csv")

# Step 3: Drop Unnecessary Columns
df = df.drop(['Restaurant ID', 'Restaurant Name', 'Address', 'Locality Verbose',
              'Switch to order menu', 'Rating color', 'Rating text'], axis=1)

# Step 4: Handle Missing Values
df['Cuisines'] = df['Cuisines'].fillna('unknown')

# Step 5: Encode Categorical Variables
le = LabelEncoder()
categorical_cols = ['City', 'Locality', 'Cuisines', 'Currency',
                    'Has Table booking', 'Has Online delivery', 'Is delivering now']

for col in categorical_cols:
    df[col] = le.fit_transform(df[col])

# Optional: One-hot encoding (not needed here because we used LabelEncoder)
# df = pd.get_dummies(df, drop_first=True)

# Step 6: Define Features and Target
X = df.drop('Aggregate rating', axis=1)
y = df['Aggregate rating']

# Step 7: Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 8: Train the Model
model = LinearRegression()
model.fit(X_train, y_train)

# Step 9: Make Predictions
y_pred = model.predict(X_test)

# Step 10: Evaluate the Model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Mean Squared Error:", mse)
print("R-squared Score:", r2)

# Step 11: Visualizations

# 1. Actual vs Predicted Ratings
plt.figure(figsize=(8, 6))
plt.scatter(y_test, y_pred, alpha=0.5, color='teal')
plt.xlabel("Actual Ratings")
plt.ylabel("Predicted Ratings")
plt.title("Actual vs Predicted Aggregate Ratings")
plt.grid(True)
plt.show()

# 2. Residual Plot
residuals = y_test - y_pred
plt.figure(figsize=(8, 6))
plt.scatter(y_pred, residuals, alpha=0.5, color='orange')
plt.axhline(y=0, color='black', linestyle='--')
plt.xlabel("Predicted Ratings")
plt.ylabel("Residuals (Actual - Predicted)")
plt.title("Residual Plot")
plt.grid(True)
plt.show()

# 3. Histogram of Errors
plt.figure(figsize=(8, 6))
plt.hist(residuals, bins=30, color='purple', edgecolor='black')
plt.title("Distribution of Prediction Errors")
plt.xlabel("Error")
plt.ylabel("Frequency")
plt.grid(True)
plt.show()

# Step 12: Show Sample Predictions
comparison = pd.DataFrame({'Actual': y_test.values, 'Predicted': y_pred})
print("\nSample Comparison:\n", comparison.head(10))








