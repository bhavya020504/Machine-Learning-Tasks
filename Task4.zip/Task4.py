import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import folium

# Load dataset
df = pd.read_csv(r"C:\Users\vimal\Downloads\Dataset .csv")

# ------------------------------
# Step 1: View Available Columns
# ------------------------------
print("Available columns:", df.columns)

# ------------------------------
# Step 2: Drop rows with missing location values
# ------------------------------
df = df.dropna(subset=['Latitude', 'Longitude', 'City', 'Locality'])

# ------------------------------
# Step 3: Basic Scatter Plot of Locations
# ------------------------------
plt.figure(figsize=(10, 6))
sns.scatterplot(data=df, x='Longitude', y='Latitude', hue='City', legend=False, alpha=0.6)
plt.title('Restaurant Locations by Latitude & Longitude')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.grid(True)
plt.tight_layout()
plt.show()

# ------------------------------
# Step 4: Number of Restaurants per City
# ------------------------------
city_counts = df['City'].value_counts().head(10)
plt.figure(figsize=(10, 5))
sns.barplot(x=city_counts.index, y=city_counts.values, palette="viridis")
plt.xticks(rotation=45)
plt.title("Top 10 Cities with Most Restaurants")
plt.ylabel("Number of Restaurants")
plt.xlabel("City")
plt.tight_layout()
plt.show()

# ------------------------------
# Step 5: Average Rating by City
# ------------------------------
avg_rating_by_city = df.groupby("City")["Aggregate rating"].mean().sort_values(ascending=False).head(10)

plt.figure(figsize=(10, 5))
sns.barplot(x=avg_rating_by_city.index, y=avg_rating_by_city.values, palette="coolwarm")
plt.xticks(rotation=45)
plt.title("Top 10 Cities by Average Restaurant Rating")
plt.ylabel("Average Rating")
plt.xlabel("City")
plt.tight_layout()
plt.show()

# ------------------------------
# Step 6: Interactive Map using Folium
# ------------------------------
# Center of the map
center_lat = df['Latitude'].mean()
center_long = df['Longitude'].mean()

map_restaurants = folium.Map(location=[center_lat, center_long], zoom_start=5)

# Add restaurant markers (only first 500 to reduce loading time)
for index, row in df.head(500).iterrows():
    folium.Marker(
        location=[row['Latitude'], row['Longitude']],
        popup=f"{row['Restaurant Name']} - {row['City']}, Rating: {row['Aggregate rating']}"
    ).add_to(map_restaurants)

# Save and show the map
map_restaurants.save("restaurant_map.html")
print("🗺️ Interactive map saved as 'restaurant_map.html'. Open it in your browser to explore.")
